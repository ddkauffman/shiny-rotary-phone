from __future__ import absolute_import, unicode_literals

from celery import Celery
from celery.schedules import crontab

import celeryconfig

app = Celery()
app.config_from_object(celeryconfig)

app.conf.update(
    result_expires=3600,
)

app.autodiscover_tasks()

app.conf.beat_schedule = {
    'verify_scheduling_works': {
        'task': 'tasks.debug_task',
        'schedule': crontab(minute='*/30'),
        'args': ()
    },
    'automatic_ingest': {
        'task': 'tasks.automatic_ingest',
        'schedule': crontab(minute='*/20'),
        'args': ()
    },
    'automatic_stats_update': {
        'task': 'tasks.automatic_stats_update',
        'schedule': crontab(minute=15, hour='02,10,18'),
        'args': ()
    },
}

if __name__ == '__main__':
    print('Called from CLI, nothing do to.')