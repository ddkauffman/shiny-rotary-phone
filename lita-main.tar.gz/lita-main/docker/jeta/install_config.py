#!/usr/bin/env python
from jeta.archive.operations import MSIDArchiveConfiguration

def execute():
    # Create empty config if not present
    MSIDArchiveConfiguration().install()

if __name__ == "__main__":
   execute()
