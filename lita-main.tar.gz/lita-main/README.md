# Lateral Ingested Telemetry Archive - LITA

This project aggregates the individual system components of the LITA system into a single repository, and is deployed to the production environment for users to interact with. Additionally, the repository houses, maintains, and organizes the project level resources. 

## What is LITA?
LITA is a system and platform that features: 
- Automated ingest of engineering telemetry from FOS
- A curated engineering telemetry data archived for every MSID (mnemonic) including GDPs
- Includes a Python package for fetching archive data from the archive, performing base analysis, and managing the archive (i.e. [jeta](https://grit.stsci.edu/fot/jeta))
- Provides a web-based data API to fetch archived telemetry data and query system state
- Provides a web portal application for interactive telemetry plotting and click-button access to tabular data 
- Provides a JupyterHub environment with a JupyterLab instance for each user to conduct comprehensive data analysis utilizing
  the entire python data science ecosystem (i.e. numpy, pandas, matplotlib, seaborn, bokeh, astropy ... etc). 

## Maintainer(s):
- David Kauffman <dkauffman@stsci.edu>
- Alex Hunter <ahunter@stsci.edu>
