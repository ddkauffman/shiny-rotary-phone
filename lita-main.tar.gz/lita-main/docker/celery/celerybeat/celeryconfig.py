imports = ('tasks',)

broker_url = 'redis://redis-server'
results_backend = 'redis://redis-server'
