import os
import datetime
import subprocess

import numpy as np
from astropy.time import Time

from jeta.staging.manage import get_staged_files
from jeta.archive import update
from jeta.archive.operations import MSIDArchiveConfiguration

from main import app

@app.task
def debug_task():
    print(f"DEBUG TASK: {Time(datetime.datetime.now(), format='datetime').yday}") 
    print('Automated task scheduling is working properly.')

@app.task
def automatic_ingest():
    print(">>> automatic ingest task triggered <<<")
    if not os.path.exists(f'{os.environ["TELEMETRY_ARCHIVE"]}/ingest.lock'):

        if get_staged_files():

            print("starting ingest, opening lock")
            with open(f'{os.environ["TELEMETRY_ARCHIVE"]}/ingest.lock', 'w') as lock_file:
                log_file_path =  f'/srv/logs/lita-automatic-ingest.{Time.now().yday.replace(":", "").replace(".", "")}.log'
                with open(log_file_path, 'a') as logfile:
                    subprocess.run(
                        args=['python','/srv/jeta/jeta/archive/ingest.py', '&'],
                        stdout=logfile,
                        stderr=logfile
                    )
                                    
            print('removing ingest lock')
            os.remove(f'{os.environ["TELEMETRY_ARCHIVE"]}/ingest.lock')

        else:
            print('skipping ingest, staging is empty')
            return 0
    else:
        print('skipping ingest, ingest is already running')
        return 0
        
        
@app.task
def automatic_stats_update():
    print(">>> automatic stats update task triggered <<<")
    
    MSIDArchiveConfiguration().load()
    if int(os.environ.get('JETA_UPDATE_STATS', True)):
    
        if not os.path.exists(f'{os.environ["TELEMETRY_ARCHIVE"]}/stats.lock'):
            print("starting stats, opening lock")
            
            with open(f'{os.environ["TELEMETRY_ARCHIVE"]}/stats.lock', 'w') as lock_file:
                log_file_path =  f'/srv/logs/lita-automatic-stats.{Time.now().yday.replace(":", "").replace(".", "")}.log'
                with open(log_file_path, 'a') as logfile:
                    subprocess.run(
                        args=['python','/srv/jeta/jeta/archive/update.py', '&'],
                        stdout=logfile,
                        stderr=logfile
                    )
                    
            print('removing stats lock')
            os.remove(f'{os.environ["TELEMETRY_ARCHIVE"]}/stats.lock')
            
        else:
            print('skipping stats update, stats is already running')
            return 0
        
    else:
        print("skipping stats update, stats update disabled in configuration")
        